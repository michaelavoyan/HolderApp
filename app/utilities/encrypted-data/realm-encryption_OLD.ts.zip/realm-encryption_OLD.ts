import RNSInfo from 'react-native-sensitive-info';
import * as Keychain from 'react-native-keychain';
import {localConfigs} from '../configs';
import {vclLogger} from './logger';
import {isIOS} from './helpers';

const REALM_KEY = 'realm_key';

const toString = (key: Uint8Array) => [...key].join(',');
const fromString = (key: string) =>
    new Uint8Array(key.split(',').map((item) => Number(item)));

const sensitiveInfoConfig = {
    keychainService: localConfigs.appPackageName,
    kSecAttrSynchronizable: true,
    sharedPreferencesName: localConfigs.appPackageName
};

export const generateRandomSecretKey = () => {
    const secretArray = crypto.getRandomValues(new Uint8Array(64));

    return {
        secretArray,
        secretString: toString(secretArray)
    };
};

const setSensitiveInfoItem = (secret: string) =>
    RNSInfo.setItem(REALM_KEY, secret, sensitiveInfoConfig);

const getStoredRealmSecretKeyCommon = async () => {
    try {
        const password = await RNSInfo.getItem(REALM_KEY, sensitiveInfoConfig);

        if (password) {
            // react-native-keychain was removed (no sync with ICloud provided),
            // for sync with ICloud it is needed to set the password with RNSInfo
            setSensitiveInfoItem(password);

            return fromString(password);
        }

        vclLogger.info(
            `Can't restoring REALM key from storage: ${JSON.stringify(
                password
            )}`
        );
    } catch (error) {
        vclLogger.error(
            `Can't restoring REALM key from storage error: ${JSON.stringify(error)}`
        );
        throw error;
    }

    const {secretArray, secretString} = generateRandomSecretKey();
    vclLogger.info(
        `getStoredRealmSecretKey - generateRandomSecretKey: ${JSON.stringify({
            secretArray,
            secretString
        })}`
    );
    try {
        const result = await setSensitiveInfoItem(secretString);

        vclLogger.info(
            `getStoredRealmSecretKey - setSensitiveInfoItem: ${JSON.stringify(
                result
            )}`
        );
    } catch (error) {
        vclLogger.error(
            `Error in RNSInfo.setItem (secret key will arive in the next log): ${JSON.stringify(
                error
            )}`
        );
        vclLogger.error(
            `The secret key of the previous error log: ${secretString}}`
        );
        throw error;
    }

    return secretArray;
};

/**
 * For backwards compatibility on android we need to keep the react-native-keychain library.
 * Check the password from keychain, if there is one, it should be set with react-native-sensitive-info
 * This functiion and react-native-keychain should be removed after a few releases
 */

const getStoredRealmSecretKeyAndroid = async () => {
    const response = await Keychain.getGenericPassword();

    if (response) {
        setSensitiveInfoItem(response.password);
    }

    return getStoredRealmSecretKeyCommon();
};

export const getStoredRealmSecretKey = isIOS
    ? getStoredRealmSecretKeyCommon
    : getStoredRealmSecretKeyAndroid;
